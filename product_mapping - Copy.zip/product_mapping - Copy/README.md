# Abbott Product Mapper — `product_mapping`

> Local Python pipeline: Stockist product name → Abbott product code & official name.

All data stays on your machine. No external API calls. No cloud upload.

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. (Optional) Run tests on synthetic data
pytest tests/ -v

# 3. Build the baseline model using synthetic sample
python src/03_build_baseline.py --sample

# 4. Predict a single name (CLI)
python src/06_predict.py --name "ALPHA CARE 10MG TABS 10'S" --sample

# 5. Launch the web UI
streamlit run app/app.py
```

---

## Loading Real Data

1. Copy your real files to `data/raw/` (never commit this folder).
2. Update column names in `config/settings.yaml` if they differ from the defaults.
3. Run the profiling script first:
   ```bash
   python src/01_profile_data.py
   ```
4. Review `outputs/reports/data_quality_report.html`.
5. Build the model:
   ```bash
   python src/03_build_baseline.py
   python src/04_train_model.py   # (once you have enough clean labels)
   ```
6. Evaluate:
   ```bash
   python src/05_evaluate.py
   ```
7. Run predictions:
   ```bash
   python src/06_predict.py --input data/raw/new_names.csv
   ```

---

## Project Structure

```
product_mapping/
  data/
    raw/          # real files — never committed
    interim/      # cleaned copies
    sample/       # synthetic CSVs (committed for testing)
  src/
    01_profile_data.py      # data quality report
    02_prepare_master.py    # normalise + cache master
    03_build_baseline.py    # TF-IDF baseline
    04_train_model.py       # supervised ranker
    05_evaluate.py          # evaluation report
    06_predict.py           # inference CLI
    utils/
      text_norm.py          # text normalisation
      attributes.py         # strength / pack-size parsing
      decision.py           # AUTO_MATCH / REVIEW / UNMATCHED
      config.py             # YAML config loader
  app/
    app.py                  # Streamlit web UI
  config/
    settings.yaml           # all configuration
  outputs/
    models/                 # saved model artefacts
    reports/                # HTML reports
    predictions/            # prediction log
  tests/                    # pytest unit + integration tests
```

---

## Decision Outcomes

| Decision | Meaning |
|---|---|
| `AUTO_MATCH` | High confidence, code in approved master, no attribute conflict |
| `REVIEW` | Plausible candidate but insufficient confidence or conflict |
| `UNMATCHED` | No acceptable candidate found |

---

## Configuration (`config/settings.yaml`)

All column names, file paths, thresholds, and model settings are in one YAML file.
No code changes needed when adapting to your actual file structure.

---

## Data Privacy

- `data/raw/` and `data/interim/` are in `.gitignore`.
- Do **not** replace the synthetic sample with real rows when sharing outside the approved environment.
- Confirm local Python processing is approved by your IT/security team before running on confidential data.
