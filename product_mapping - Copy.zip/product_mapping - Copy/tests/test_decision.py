"""
tests/test_decision.py
----------------------
Unit tests for the decision policy (AUTO_MATCH / REVIEW / UNMATCHED).
"""

import sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.decision import make_decision, Decision

APPROVED = {"DEMO001", "DEMO002", "DEMO003"}


class TestMakeDecision:
    def _decide(self, top_score, second_score, top_code, conflict=False):
        return make_decision(
            top_score=top_score,
            second_score=second_score,
            top_code=top_code,
            top_name="Test Product",
            approved_codes=APPROVED,
            has_attribute_conflict=conflict,
            attribute_summary="Strength=MATCH; PackSize=MATCH; StrengthType=MATCH",
            auto_match_min_score=0.60,
            auto_match_min_gap=0.10,
            review_min_score=0.20,
        )

    def test_auto_match_all_criteria_pass(self):
        result = self._decide(top_score=0.85, second_score=0.40, top_code="DEMO001")
        assert result.decision == Decision.AUTO_MATCH

    def test_unmatched_below_review_threshold(self):
        result = self._decide(top_score=0.10, second_score=0.05, top_code="DEMO001")
        assert result.decision == Decision.UNMATCHED

    def test_review_score_too_low_for_auto(self):
        result = self._decide(top_score=0.50, second_score=0.10, top_code="DEMO001")
        assert result.decision == Decision.REVIEW

    def test_review_gap_too_small(self):
        # Both candidates close → ambiguous
        result = self._decide(top_score=0.75, second_score=0.70, top_code="DEMO001")
        assert result.decision == Decision.REVIEW

    def test_review_attribute_conflict(self):
        result = self._decide(top_score=0.85, second_score=0.40, top_code="DEMO001", conflict=True)
        assert result.decision == Decision.REVIEW

    def test_review_code_not_in_master(self):
        result = make_decision(
            top_score=0.85,
            second_score=0.40,
            top_code="UNKNOWN999",
            top_name="Unknown Product",
            approved_codes=APPROVED,
            has_attribute_conflict=False,
            attribute_summary="",
        )
        assert result.decision == Decision.REVIEW

    def test_none_code_is_unmatched(self):
        result = make_decision(
            top_score=0.80,
            second_score=0.30,
            top_code=None,
            top_name=None,
            approved_codes=APPROVED,
            has_attribute_conflict=False,
            attribute_summary="",
        )
        assert result.decision == Decision.UNMATCHED

    def test_auto_match_returns_correct_code(self):
        result = self._decide(top_score=0.90, second_score=0.30, top_code="DEMO002")
        assert result.predicted_code == "DEMO002"

    def test_review_reason_not_empty(self):
        result = self._decide(top_score=0.50, second_score=0.10, top_code="DEMO001")
        assert result.reason and len(result.reason) > 0

    def test_scores_preserved(self):
        result = self._decide(top_score=0.82, second_score=0.35, top_code="DEMO001")
        assert abs(result.top_score - 0.82) < 1e-6
        assert abs(result.second_score - 0.35) < 1e-6
