"""
tests/test_pipeline_sample.py
-----------------------------
End-to-end integration test using the bundled synthetic sample data.
Verifies the full pipeline: master prep → baseline build → prediction.
"""

import sys
import pickle
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.config import load_config
from src.utils.text_norm import build_alias_map_from_config
from src.prepare_master import prepare_master
from src.build_baseline import TFIDFRetriever, predict_one


@pytest.fixture(scope="module")
def setup():
    cfg = load_config()
    master_path = ROOT / cfg["paths"]["sample_master"]
    master_df = prepare_master(master_path, cfg)
    mcols = cfg["master_columns"]
    retrieval_cfg = cfg["retrieval"]

    retriever = TFIDFRetriever(
        master_df=master_df,
        mcols=mcols,
        ngram_range=tuple(retrieval_cfg["tfidf_ngram_range"]),
        analyzer=retrieval_cfg["tfidf_analyzer"],
        top_k=retrieval_cfg["top_k"],
        min_sim=retrieval_cfg["min_similarity_threshold"],
    )
    approved_codes = set(master_df[mcols["product_code"]].dropna().astype(str))
    alias_map = build_alias_map_from_config(cfg)
    return retriever, approved_codes, alias_map, cfg


class TestPipelineSample:
    def test_exact_match_ranked_first(self, setup):
        retriever, approved_codes, alias_map, cfg = setup
        result = predict_one(
            "ALPHA CARE 10 MG TABLETS 10S",
            retriever, approved_codes, alias_map, cfg
        )
        assert result["predicted_company_product_code"] == "DEMO001"

    def test_abbreviation_variant_resolves(self, setup):
        """ALPHA CARE 10MG TABS 10'S should map to DEMO001."""
        retriever, approved_codes, alias_map, cfg = setup
        result = predict_one(
            "ALPHA CARE 10MG TABS 10'S",
            retriever, approved_codes, alias_map, cfg
        )
        assert result["predicted_company_product_code"] == "DEMO001"

    def test_liquid_variant_resolves(self, setup):
        """BETA MINT LIQ 100ML should map to DEMO002."""
        retriever, approved_codes, alias_map, cfg = setup
        result = predict_one(
            "BETA MINT LIQ 100ML",
            retriever, approved_codes, alias_map, cfg
        )
        assert result["predicted_company_product_code"] == "DEMO002"

    def test_ambiguous_name_not_auto_matched(self, setup):
        """'ALPHA CARE TABLETS' is ambiguous between DEMO001 and DEMO005."""
        retriever, approved_codes, alias_map, cfg = setup
        result = predict_one(
            "ALPHA CARE TABLETS",
            retriever, approved_codes, alias_map, cfg
        )
        assert result["decision"] != "AUTO_MATCH", (
            f"Ambiguous name should not be AUTO_MATCH. Got: {result['decision']}, "
            f"code: {result['predicted_company_product_code']}, "
            f"score: {result['top_candidate_score']}, "
            f"gap: {result['top_candidate_score'] - result['second_candidate_score']}"
        )

    def test_unknown_brand_unmatched_or_review(self, setup):
        """UNKNOWN BRAND 999 MG should return UNMATCHED or REVIEW, never AUTO_MATCH."""
        retriever, approved_codes, alias_map, cfg = setup
        result = predict_one(
            "UNKNOWN BRAND 999 MG",
            retriever, approved_codes, alias_map, cfg
        )
        assert result["decision"] in ("UNMATCHED", "REVIEW")

    def test_output_has_required_columns(self, setup):
        retriever, approved_codes, alias_map, cfg = setup
        result = predict_one(
            "ALPHA CARE 10 MG TABLETS 10S",
            retriever, approved_codes, alias_map, cfg
        )
        required = [
            "stockist_given_product_name",
            "predicted_company_product_code",
            "predicted_company_product_name",
            "decision",
            "top_candidate_score",
            "second_candidate_score",
            "attribute_check_status",
            "review_reason",
            "model_version",
        ]
        for col in required:
            assert col in result, f"Missing output column: {col}"

    def test_predicted_code_always_in_master(self, setup):
        """All non-UNMATCHED predictions must point to a code in the approved master."""
        retriever, approved_codes, alias_map, cfg = setup
        test_names = [
            "ALPHA CARE 10 MG TABLETS 10S",
            "BETA MINT LIQ 100ML",
            "GAMMA PLUS CAPS 20MG 15S",
            "DELTA ORAL SUSP 60ML",
        ]
        for name in test_names:
            result = predict_one(name, retriever, approved_codes, alias_map, cfg)
            code = result["predicted_company_product_code"]
            if result["decision"] != "UNMATCHED" and code is not None:
                assert code in approved_codes, (
                    f"Predicted code '{code}' for '{name}' is not in the approved master."
                )

    def test_na_strength_treated_as_unknown(self, setup):
        """BETA MINT (strength = N/A in master) should not produce attribute MISMATCH."""
        retriever, approved_codes, alias_map, cfg = setup
        result = predict_one(
            "BETA MINT LIQUID 100 ML",
            retriever, approved_codes, alias_map, cfg
        )
        assert "MISMATCH" not in result["attribute_check_status"] or result["decision"] in (
            "REVIEW", "AUTO_MATCH"
        )
