"""
tests/test_text_norm.py
-----------------------
Unit tests for the text normalisation utilities.
"""

import sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.text_norm import normalise


class TestNormalise:
    def test_basic_uppercase(self):
        assert normalise("alpha care") == "ALPHA CARE"

    def test_strip_whitespace(self):
        assert normalise("  ALPHA CARE  ") == "ALPHA CARE"

    def test_collapse_spaces(self):
        assert normalise("ALPHA   CARE   10MG") == "ALPHA CARE 10MG"

    def test_apostrophe_pack_count(self):
        # 10'S → 10S
        result = normalise("ALPHA CARE 10MG 10'S")
        assert "10S" in result
        assert "10'S" not in result

    def test_missing_tokens_return_none(self):
        for token in ["N/A", "NA", "NULL", "NONE", "nil", "n/a", ""]:
            assert normalise(token) is None, f"Expected None for: {repr(token)}"

    def test_none_input(self):
        assert normalise(None) is None

    def test_nan_input(self):
        import math
        assert normalise(float("nan")) is None

    def test_alias_tabs_to_tablets(self):
        result = normalise("ALPHA CARE TABS 10MG")
        assert "TABLETS" in result

    def test_alias_caps_to_capsules(self):
        result = normalise("GAMMA CAPS 20MG")
        assert "CAPSULES" in result

    def test_alias_liq_to_liquid(self):
        result = normalise("BETA LIQ 100ML")
        assert "LIQUID" in result

    def test_digits_preserved(self):
        result = normalise("PRODUCT 8MG TABLETS")
        assert "8MG" in result

    def test_strength_tokens_not_stripped(self):
        # 8MG and 16MG should remain distinct
        r1 = normalise("ALPHA 8MG TABLETS")
        r2 = normalise("ALPHA 16MG TABLETS")
        assert r1 != r2

    def test_preserves_non_alias_abbreviations(self):
        # ML should stay as ML (it's a pack unit, not a name alias)
        result = normalise("BETA MINT 100ML LIQUID")
        assert "ML" in result
