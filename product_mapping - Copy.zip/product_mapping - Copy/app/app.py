"""
app/app.py
----------
Streamlit web UI for the Stockist → Abbott Product Mapping system.

Run from the project root:
    streamlit run app/app.py
"""

import sys
import pickle
from pathlib import Path
from datetime import datetime

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.config import load_config
from src.utils.text_norm import normalise, build_alias_map_from_config
from src.build_baseline import TFIDFRetriever, predict_one
from src.prepare_master import prepare_master

# ──────────────────────────────────────────────────────────────────────────────
# Page config
# ──────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Abbott Product Mapper",
    page_icon="💊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ──────────────────────────────────────────────────────────────────────────────
# CSS styling
# ──────────────────────────────────────────────────────────────────────────────
st.markdown(
    """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

/* Dark gradient background */
.stApp {
    background: linear-gradient(135deg, #0f0c29 0%, #1a1a3e 50%, #0f0c29 100%);
    min-height: 100vh;
}

/* Header */
.hero-header {
    text-align: center;
    padding: 2.5rem 1rem 1.5rem;
}
.hero-header h1 {
    font-size: 2.6rem;
    font-weight: 700;
    background: linear-gradient(90deg, #a78bfa, #60a5fa, #34d399);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 0.4rem;
}
.hero-header p {
    color: #94a3b8;
    font-size: 1.05rem;
    font-weight: 300;
}

/* Decision badge */
.badge {
    display: inline-block;
    padding: 0.35rem 1.1rem;
    border-radius: 999px;
    font-weight: 600;
    font-size: 0.9rem;
    letter-spacing: 0.05em;
    text-transform: uppercase;
}
.badge-auto   { background: rgba(52,211,153,0.18); color: #34d399; border: 1px solid #34d399; }
.badge-review { background: rgba(251,191, 36,0.18); color: #fbbf24; border: 1px solid #fbbf24; }
.badge-unmatch{ background: rgba(239, 68, 68,0.18); color: #f87171; border: 1px solid #f87171; }

/* Result card */
.result-card {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 16px;
    padding: 1.6rem 2rem;
    backdrop-filter: blur(12px);
    margin-top: 1.2rem;
}
.result-card h2 {
    font-size: 1.1rem;
    font-weight: 600;
    color: #e2e8f0;
    margin-bottom: 0.8rem;
    border-bottom: 1px solid rgba(255,255,255,0.08);
    padding-bottom: 0.6rem;
}
.metric-row {
    display: flex;
    gap: 1.2rem;
    flex-wrap: wrap;
    margin-top: 0.8rem;
}
.metric-box {
    background: rgba(255,255,255,0.06);
    border-radius: 10px;
    padding: 0.8rem 1.2rem;
    flex: 1;
    min-width: 130px;
}
.metric-box .label {
    font-size: 0.72rem;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 0.3rem;
}
.metric-box .value {
    font-size: 1.3rem;
    font-weight: 600;
    color: #f1f5f9;
}

/* Score bar */
.score-bar-wrap { margin-top: 0.4rem; }
.score-bar-bg {
    background: rgba(255,255,255,0.08);
    border-radius: 999px;
    height: 8px;
    width: 100%;
    overflow: hidden;
    margin-top: 0.25rem;
}
.score-bar-fill {
    height: 100%;
    border-radius: 999px;
    transition: width 0.5s ease;
}

/* Candidate table */
.cand-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 0.6rem;
    font-size: 0.82rem;
}
.cand-table th {
    background: rgba(167,139,250,0.2);
    color: #c4b5fd;
    padding: 7px 10px;
    text-align: left;
    font-weight: 600;
    border-radius: 4px;
}
.cand-table td {
    color: #cbd5e1;
    padding: 6px 10px;
    border-bottom: 1px solid rgba(255,255,255,0.06);
}
.cand-table tr:hover td { background: rgba(255,255,255,0.04); }

/* Sidebar */
section[data-testid="stSidebar"] {
    background: rgba(255,255,255,0.04);
    border-right: 1px solid rgba(255,255,255,0.08);
}

/* Input widgets */
.stTextInput > div > div > input,
.stTextArea > div > div > textarea {
    background: rgba(255,255,255,0.07) !important;
    border: 1px solid rgba(255,255,255,0.15) !important;
    border-radius: 10px !important;
    color: #f1f5f9 !important;
    font-family: 'Inter', sans-serif !important;
}
.stButton > button {
    background: linear-gradient(135deg, #7c3aed, #2563eb) !important;
    color: white !important;
    border: none !important;
    border-radius: 10px !important;
    padding: 0.6rem 2rem !important;
    font-weight: 600 !important;
    font-family: 'Inter', sans-serif !important;
    transition: opacity 0.2s ease !important;
}
.stButton > button:hover { opacity: 0.85 !important; }

/* History table */
.hist-table-wrap {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px;
    padding: 1rem;
    margin-top: 1rem;
}
</style>
""",
    unsafe_allow_html=True,
)

# ──────────────────────────────────────────────────────────────────────────────
# Load config + model (cached)
# ──────────────────────────────────────────────────────────────────────────────

@st.cache_resource(show_spinner="Loading model…")
def get_model(use_sample: bool = True):
    cfg = load_config()
    alias_map = build_alias_map_from_config(cfg)

    model_path = ROOT / cfg["paths"]["models_dir"] / "tfidf_baseline.pkl"

    if model_path.exists():
        with open(model_path, "rb") as f:
            obj = pickle.load(f)
        retriever = obj["retriever"]
        master_df = obj["master_df"]
        approved_codes = obj["approved_codes"]
    else:
        # Build on the fly from sample
        master_csv = ROOT / cfg["paths"]["sample_master" if use_sample else "master_file"]
        master_df = prepare_master(master_csv, cfg)
        mcols = cfg["master_columns"]
        ret_cfg = cfg["retrieval"]
        retriever = TFIDFRetriever(
            master_df=master_df,
            mcols=mcols,
            ngram_range=tuple(ret_cfg["tfidf_ngram_range"]),
            analyzer=ret_cfg["tfidf_analyzer"],
            top_k=ret_cfg["top_k"],
            min_sim=ret_cfg["min_similarity_threshold"],
        )
        approved_codes = set(master_df[mcols["product_code"]].dropna().astype(str))

    return retriever, master_df, approved_codes, alias_map, cfg


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _badge_html(decision: str) -> str:
    cls = {
        "AUTO_MATCH": "badge-auto",
        "REVIEW": "badge-review",
        "UNMATCHED": "badge-unmatch",
    }.get(decision, "badge-unmatch")
    label = {"AUTO_MATCH": "✅ Auto Match", "REVIEW": "⚠️ Review", "UNMATCHED": "❌ Unmatched"}.get(
        decision, decision
    )
    return f'<span class="badge {cls}">{label}</span>'


def _score_bar(score: float, colour: str = "#7c3aed") -> str:
    pct = int(score * 100)
    return (
        f'<div class="score-bar-wrap">'
        f'<div class="score-bar-bg">'
        f'<div class="score-bar-fill" style="width:{pct}%;background:{colour}"></div>'
        f"</div></div>"
    )


def _candidate_table_html(candidates: pd.DataFrame, mcols: dict) -> str:
    pc = mcols["product_code"]
    pn = mcols["product_name"]
    ps = mcols["pack_size"]
    st_col = mcols["strength"]
    rows = ""
    for _, row in candidates.iterrows():
        score = row.get("score", 0)
        bar = _score_bar(score, "#60a5fa")
        rows += (
            f"<tr>"
            f"<td>{row.get(pc,'')}</td>"
            f"<td>{row.get(pn,'')}</td>"
            f"<td>{row.get(st_col,'')}</td>"
            f"<td>{row.get(ps,'')}</td>"
            f"<td>{score:.3f}{bar}</td>"
            f"</tr>"
        )
    return (
        f'<table class="cand-table">'
        f"<thead><tr><th>Code</th><th>Official Name</th><th>Strength</th>"
        f"<th>Pack Size</th><th>Score</th></tr></thead>"
        f"<tbody>{rows}</tbody></table>"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Session state
# ──────────────────────────────────────────────────────────────────────────────
if "history" not in st.session_state:
    st.session_state.history = []

# ──────────────────────────────────────────────────────────────────────────────
# Sidebar
# ──────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Settings")
    use_sample = st.toggle("Use synthetic sample data", value=True)

    st.markdown("---")
    st.markdown("### Thresholds")
    auto_thresh = st.slider("Auto-match min score", 0.0, 1.0, 0.60, 0.01)
    gap_thresh = st.slider("Min score gap", 0.0, 0.5, 0.10, 0.01)
    review_thresh = st.slider("Review min score", 0.0, 0.5, 0.20, 0.01)

    st.markdown("---")
    st.markdown("### Info")
    st.info(
        "All processing runs **locally**. No data leaves your machine. "
        "Use synthetic data for development; load real files under company policy."
    )

    if st.button("🗑 Clear history"):
        st.session_state.history = []
        st.rerun()

# ──────────────────────────────────────────────────────────────────────────────
# Load model
# ──────────────────────────────────────────────────────────────────────────────
retriever, master_df, approved_codes, alias_map, cfg = get_model(use_sample=use_sample)
mcols = cfg["master_columns"]

# Override thresholds from sidebar
cfg["decision"]["auto_match_min_score"] = auto_thresh
cfg["decision"]["auto_match_min_gap"] = gap_thresh
cfg["decision"]["review_min_score"] = review_thresh

# ──────────────────────────────────────────────────────────────────────────────
# Header
# ──────────────────────────────────────────────────────────────────────────────
st.markdown(
    """
<div class="hero-header">
    <h1>💊 Abbott Product Mapper</h1>
    <p>Map stockist product names to the official Abbott product master — locally, privately, auditably.</p>
</div>
""",
    unsafe_allow_html=True,
)

# ──────────────────────────────────────────────────────────────────────────────
# Tabs
# ──────────────────────────────────────────────────────────────────────────────
tab_single, tab_batch, tab_history, tab_master = st.tabs(
    ["🔍 Single Lookup", "📂 Batch CSV", "📋 History", "📦 Master Browser"]
)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — Single lookup
# ══════════════════════════════════════════════════════════════════════════════
with tab_single:
    col_input, col_result = st.columns([1, 1], gap="large")

    with col_input:
        st.markdown("### Enter stockist product name")
        product_input = st.text_input(
            "Stockist product name",
            placeholder="e.g. ALPHA CARE 10MG TABS 10'S",
            label_visibility="collapsed",
        )
        stockist_code = st.text_input("Stockist code (optional)", placeholder="e.g. STK001")

        st.markdown("#### Quick examples")
        examples = [
            "ALPHA CARE 10MG TABS 10'S",
            "BETA MINT LIQ 100ML",
            "ALPHA CARE TABLETS",
            "UNKNOWN BRAND 999 MG",
            "DELTA ORAL SUSP 60ML",
        ]
        for ex in examples:
            if st.button(ex, key=f"ex_{ex}"):
                product_input = ex

        predict_btn = st.button("🔍 Map Product", use_container_width=True)

    with col_result:
        if predict_btn and product_input.strip():
            with st.spinner("Mapping…"):
                result = predict_one(
                    raw_name=product_input.strip(),
                    retriever=retriever,
                    approved_codes=approved_codes,
                    alias_map=alias_map,
                    cfg=cfg,
                )
                result["stockist_code"] = stockist_code
                result["timestamp"] = datetime.now().isoformat(timespec="seconds")
                st.session_state.history.append(result)

            decision = result["decision"]
            badge = _badge_html(decision)
            norm_name = normalise(product_input.strip(), alias_map=alias_map) or "—"

            st.markdown(
                f"""
<div class="result-card">
  <h2>Result {badge}</h2>
  <div class="metric-row">
    <div class="metric-box">
      <div class="label">Predicted Code</div>
      <div class="value">{result['predicted_company_product_code'] or '—'}</div>
    </div>
    <div class="metric-box">
      <div class="label">Top Score</div>
      <div class="value">{result['top_candidate_score']:.3f}</div>
      {_score_bar(result['top_candidate_score'])}
    </div>
    <div class="metric-box">
      <div class="label">2nd Score</div>
      <div class="value">{result['second_candidate_score']:.3f}</div>
      {_score_bar(result['second_candidate_score'], '#60a5fa')}
    </div>
  </div>

  <div style="margin-top:1rem">
    <div style="color:#94a3b8;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.07em">Official Name</div>
    <div style="color:#f1f5f9;font-size:1rem;margin-top:0.2rem">{result['predicted_company_product_name'] or '—'}</div>
  </div>

  <div style="margin-top:0.8rem">
    <div style="color:#94a3b8;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.07em">Normalised Input</div>
    <div style="color:#a5b4fc;font-size:0.9rem;margin-top:0.2rem;font-family:monospace">{norm_name}</div>
  </div>

  <div style="margin-top:0.8rem">
    <div style="color:#94a3b8;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.07em">Attribute Check</div>
    <div style="color:#cbd5e1;font-size:0.85rem;margin-top:0.2rem">{result['attribute_check_status'] or '—'}</div>
  </div>

  <div style="margin-top:0.8rem">
    <div style="color:#94a3b8;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.07em">Reason</div>
    <div style="color:#cbd5e1;font-size:0.85rem;margin-top:0.2rem">{result['review_reason']}</div>
  </div>
</div>
""",
                unsafe_allow_html=True,
            )

            # Candidate shortlist
            candidates = retriever.retrieve(norm_name if norm_name != "—" else product_input)
            if not candidates.empty:
                st.markdown("#### Candidate Shortlist")
                st.markdown(
                    _candidate_table_html(candidates, mcols), unsafe_allow_html=True
                )

        elif predict_btn:
            st.warning("Please enter a product name.")
        else:
            st.markdown(
                """
<div style="text-align:center;padding:4rem 2rem;color:#475569">
  <div style="font-size:3rem">💊</div>
  <div style="font-size:1rem;margin-top:0.5rem">Enter a product name and click <b>Map Product</b></div>
</div>
""",
                unsafe_allow_html=True,
            )

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — Batch CSV
# ══════════════════════════════════════════════════════════════════════════════
with tab_batch:
    st.markdown("### Batch Prediction from CSV")
    st.info(
        "Upload a CSV with at minimum a column for the stockist product name. "
        "Results will be displayed and available for download."
    )

    uploaded = st.file_uploader("Upload CSV", type=["csv"])
    name_col_input = st.text_input("Name column", value="stockist_given_product_name")
    sc_col_input = st.text_input("Stockist code column (optional)", value="stockist_code")

    if uploaded is not None:
        input_df = pd.read_csv(uploaded, dtype=str, keep_default_na=False)
        st.write(f"**{len(input_df)} rows loaded.** Preview:")
        st.dataframe(input_df.head(5), use_container_width=True)

        if name_col_input not in input_df.columns:
            st.error(f"Column '{name_col_input}' not found in CSV.")
        else:
            if st.button("▶️ Run Batch Prediction", use_container_width=True):
                names = input_df[name_col_input].tolist()
                codes = (
                    input_df[sc_col_input].tolist()
                    if sc_col_input in input_df.columns
                    else [""] * len(names)
                )

                progress = st.progress(0, text="Predicting…")
                results = []
                for i, (name, sc) in enumerate(zip(names, codes)):
                    res = predict_one(name, retriever, approved_codes, alias_map, cfg)
                    res["stockist_code"] = sc
                    res["timestamp"] = datetime.now().isoformat(timespec="seconds")
                    results.append(res)
                    progress.progress((i + 1) / len(names), text=f"Row {i+1}/{len(names)}")

                results_df = pd.DataFrame(results)
                st.session_state.history.extend(results)

                # Decision breakdown
                dec_counts = results_df["decision"].value_counts()
                c1, c2, c3 = st.columns(3)
                c1.metric("✅ AUTO_MATCH", dec_counts.get("AUTO_MATCH", 0))
                c2.metric("⚠️ REVIEW", dec_counts.get("REVIEW", 0))
                c3.metric("❌ UNMATCHED", dec_counts.get("UNMATCHED", 0))

                st.dataframe(results_df, use_container_width=True)

                csv_bytes = results_df.to_csv(index=False).encode("utf-8")
                st.download_button(
                    "⬇️ Download Results CSV",
                    data=csv_bytes,
                    file_name="mapping_results.csv",
                    mime="text/csv",
                )

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — History
# ══════════════════════════════════════════════════════════════════════════════
with tab_history:
    st.markdown("### Prediction History (this session)")
    if not st.session_state.history:
        st.info("No predictions made yet in this session.")
    else:
        hist_df = pd.DataFrame(st.session_state.history)
        # Colour-code decision column
        def _style_decision(val):
            colour = {"AUTO_MATCH": "#34d399", "REVIEW": "#fbbf24", "UNMATCHED": "#f87171"}.get(
                val, "#94a3b8"
            )
            return f"color: {colour}; font-weight: 600"

        disp_cols = [
            "timestamp",
            "stockist_code",
            "stockist_given_product_name",
            "predicted_company_product_code",
            "predicted_company_product_name",
            "decision",
            "top_candidate_score",
        ]
        available = [c for c in disp_cols if c in hist_df.columns]
        styled = hist_df[available].style.applymap(_style_decision, subset=["decision"])
        st.dataframe(styled, use_container_width=True)

        csv_bytes = hist_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            "⬇️ Download History CSV",
            data=csv_bytes,
            file_name="prediction_history.csv",
            mime="text/csv",
        )

# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — Master Browser
# ══════════════════════════════════════════════════════════════════════════════
with tab_master:
    st.markdown("### Product Master Browser")
    search_term = st.text_input("Search master by name or code", placeholder="e.g. ALPHA or DEMO001")

    display_df = master_df[[mcols["product_code"], mcols["product_name"],
                             mcols["strength"], mcols["pack_size"],
                             mcols["strength_type"]]].copy()

    if search_term.strip():
        mask = (
            display_df[mcols["product_name"]].str.contains(search_term.strip(), case=False, na=False)
            | display_df[mcols["product_code"]].str.contains(search_term.strip(), case=False, na=False)
        )
        display_df = display_df[mask]

    st.markdown(f"**{len(display_df)} product(s)** in master{' (filtered)' if search_term.strip() else ''}.")
    st.dataframe(display_df, use_container_width=True)
