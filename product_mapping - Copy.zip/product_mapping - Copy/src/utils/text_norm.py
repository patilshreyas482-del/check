"""
utils/text_norm.py
------------------
Text normalisation helpers for product name standardisation.

Rules applied (in order):
  1. Coerce to string, strip leading/trailing whitespace.
  2. Replace missing-value tokens with NaN (not normalised further).
  3. Convert to uppercase.
  4. Collapse repeated whitespace.
  5. Normalise common punctuation (apostrophes in pack counts like 10'S → 10S).
  6. Expand controlled abbreviation aliases.
  7. Collapse spaces again after alias expansion.
"""

import re
import math
import pandas as pd
from typing import Optional

# ---------------------------------------------------------------------------
# Missing-value tokens (returned as pd.NA / None after check)
# ---------------------------------------------------------------------------
_MISSING_TOKENS = {"N/A", "NA", "NULL", "NONE", "NIL", "-", "--", ""}


def _is_missing(token: str) -> bool:
    return token.strip().upper() in _MISSING_TOKENS


# ---------------------------------------------------------------------------
# Default alias map (override via config)
# ---------------------------------------------------------------------------
_DEFAULT_ALIAS_MAP: dict[str, str] = {
    r"\bTABS\b": "TABLETS",
    r"\bTAB\b": "TABLETS",
    r"\bCAPS\b": "CAPSULES",
    r"\bCAP\b": "CAPSULES",
    r"\bLIQ\b": "LIQUID",
    r"\bSUSP\b": "SUSPENSION",
    r"\bSOL\b": "SOLUTION",
    r"\bINJ\b": "INJECTION",
    r"\bSYR\b": "SYRUP",
    r"\bOINT\b": "OINTMENT",
    r"\bCRM\b": "CREAM",
    r"\bGEL\b": "GEL",
    r"\bDRP\b": "DROPS",
    r"\bDRPS\b": "DROPS",
    r"\bSACHET\b": "SACHET",
    r"\bSACHETS\b": "SACHETS",
    r"\bCAP\b": "CAPSULES",
    r"\bTBLT\b": "TABLETS",
}


def _build_alias_map(alias_config: Optional[dict] = None) -> dict[str, str]:
    """Merge config-supplied aliases with defaults (config takes precedence)."""
    merged = dict(_DEFAULT_ALIAS_MAP)
    if alias_config:
        for raw, replacement in alias_config.items():
            pattern = r"\b" + re.escape(raw.upper()) + r"\b"
            merged[pattern] = replacement.upper()
    return merged


# ---------------------------------------------------------------------------
# Core normalise function
# ---------------------------------------------------------------------------
def normalise(
    name: str,
    alias_map: Optional[dict] = None,
) -> Optional[str]:
    """
    Normalise a product name string.

    Returns None if the input is a recognised missing-value token (N/A etc.).
    Preserves all digits and strength/pack tokens; only replaces known aliases.
    """
    if name is None or (isinstance(name, float) and math.isnan(name)):
        return None

    text = str(name).strip()

    if _is_missing(text):
        return None

    # Uppercase
    text = text.upper()

    # Normalise apostrophe pack counts: 10'S → 10S, 15'S → 15S
    text = re.sub(r"(\d+)'S\b", r"\1S", text)

    # Collapse repeated whitespace / tabs / newlines
    text = re.sub(r"\s+", " ", text).strip()

    # Apply alias expansion
    active_map = alias_map if alias_map is not None else _DEFAULT_ALIAS_MAP
    for pattern, replacement in active_map.items():
        text = re.sub(pattern, replacement, text)

    # Collapse spaces again after expansion
    text = re.sub(r"\s+", " ", text).strip()

    return text


# ---------------------------------------------------------------------------
# Series / DataFrame helpers
# ---------------------------------------------------------------------------
def normalise_series(
    series: pd.Series,
    alias_map: Optional[dict] = None,
) -> pd.Series:
    """Apply normalise() element-wise to a pandas Series."""
    return series.apply(lambda x: normalise(x, alias_map=alias_map))


def build_alias_map_from_config(cfg: dict) -> dict:
    """Build the regex alias map from a loaded settings.yaml dict."""
    raw = cfg.get("normalisation", {}).get("alias_map", {})
    return _build_alias_map(raw)
