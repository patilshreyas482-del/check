"""
utils/attributes.py
-------------------
Parse and compare pack size, strength, and strength type attributes.

Design rules:
  - N/A / blank / null → treated as UNKNOWN (not a mismatch, not a match).
  - Explicit numeric value on both sides → compare.
  - If one side is UNKNOWN → no evidence (neither match nor mismatch).
  - Unit comparison is case-insensitive and normalises common aliases.
"""

import re
from typing import Optional
from dataclasses import dataclass
from enum import Enum


class AttributeResult(Enum):
    MATCH = "MATCH"
    MISMATCH = "MISMATCH"
    UNKNOWN = "UNKNOWN"   # one or both sides missing → no evidence


# ---------------------------------------------------------------------------
# Unit normalisation maps
# ---------------------------------------------------------------------------
_STRENGTH_UNIT_MAP = {
    "MG": "MG",
    "MCG": "MCG",
    "MICROG": "MCG",
    "MICROGRAM": "MCG",
    "G": "G",
    "GM": "G",
    "GRAM": "G",
    "ML": "ML",
    "MEQ": "MEQ",
    "IU": "IU",
    "UNITS": "UNITS",
    "UNIT": "UNITS",
    "%": "%",
}

_PACK_UNIT_MAP = {
    "TABLETS": "TABLETS",
    "TABLET": "TABLETS",
    "TABS": "TABLETS",
    "TAB": "TABLETS",
    "CAPSULES": "CAPSULES",
    "CAPSULE": "CAPSULES",
    "CAPS": "CAPSULES",
    "CAP": "CAPSULES",
    "ML": "ML",
    "L": "L",
    "G": "G",
    "GM": "G",
    "SACHETS": "SACHETS",
    "SACHET": "SACHETS",
    "VIALS": "VIALS",
    "VIAL": "VIALS",
    "DROPS": "DROPS",
    "DROP": "DROPS",
}

_MISSING_TOKENS = {"N/A", "NA", "NULL", "NONE", "NIL", "", "-", "--"}

_STRENGTH_TYPE_MAP = {
    "TABLET": "TABLET",
    "TABLETS": "TABLET",
    "CAPSULE": "CAPSULE",
    "CAPSULES": "CAPSULE",
    "LIQUID": "LIQUID",
    "SYRUP": "LIQUID",
    "SUSPENSION": "SUSPENSION",
    "SUSP": "SUSPENSION",
    "SOLUTION": "SOLUTION",
    "SOL": "SOLUTION",
    "INJECTION": "INJECTION",
    "INJ": "INJECTION",
    "DROPS": "DROPS",
    "DROP": "DROPS",
    "CREAM": "CREAM",
    "GEL": "GEL",
    "OINTMENT": "OINTMENT",
    "SACHET": "SACHET",
    "SACHETS": "SACHET",
}


def _is_missing(val: Optional[str]) -> bool:
    if val is None:
        return True
    return str(val).strip().upper() in _MISSING_TOKENS


# ---------------------------------------------------------------------------
# Parsers
# ---------------------------------------------------------------------------
@dataclass
class ParsedStrength:
    value: Optional[float]
    unit: Optional[str]
    raw: str


@dataclass
class ParsedPackSize:
    value: Optional[float]
    unit: Optional[str]
    raw: str


def parse_strength(raw: Optional[str]) -> ParsedStrength:
    """Extract numeric value and unit from a strength string like '10 mg' or '10MG'."""
    if _is_missing(raw):
        return ParsedStrength(value=None, unit=None, raw=str(raw) if raw else "")

    text = str(raw).strip().upper()
    # Pattern: optional number, optional space, unit
    m = re.match(r"([\d.]+)\s*([A-Z%]+)", text)
    if not m:
        return ParsedStrength(value=None, unit=None, raw=raw)

    val = float(m.group(1))
    raw_unit = m.group(2)
    unit = _STRENGTH_UNIT_MAP.get(raw_unit, raw_unit)
    return ParsedStrength(value=val, unit=unit, raw=raw)


def parse_pack_size(raw: Optional[str]) -> ParsedPackSize:
    """Extract numeric value and unit from a pack-size string like '10 tablets'."""
    if _is_missing(raw):
        return ParsedPackSize(value=None, unit=None, raw=str(raw) if raw else "")

    text = str(raw).strip().upper()
    m = re.match(r"([\d.]+)\s*([A-Z]+)", text)
    if not m:
        return ParsedPackSize(value=None, unit=None, raw=raw)

    val = float(m.group(1))
    raw_unit = m.group(2)
    unit = _PACK_UNIT_MAP.get(raw_unit, raw_unit)
    return ParsedPackSize(value=val, unit=unit, raw=raw)


def normalise_strength_type(raw: Optional[str]) -> Optional[str]:
    if _is_missing(raw):
        return None
    return _STRENGTH_TYPE_MAP.get(str(raw).strip().upper(), str(raw).strip().upper())


# ---------------------------------------------------------------------------
# Comparison functions
# ---------------------------------------------------------------------------
def compare_strength(a: Optional[str], b: Optional[str]) -> AttributeResult:
    """Compare two strength strings. Returns MATCH, MISMATCH, or UNKNOWN."""
    pa = parse_strength(a)
    pb = parse_strength(b)

    if pa.value is None or pb.value is None:
        return AttributeResult.UNKNOWN

    if pa.unit != pb.unit:
        # Units differ and both are known → likely a real mismatch
        return AttributeResult.MISMATCH

    return AttributeResult.MATCH if abs(pa.value - pb.value) < 1e-6 else AttributeResult.MISMATCH


def compare_pack_size(a: Optional[str], b: Optional[str]) -> AttributeResult:
    """Compare two pack-size strings."""
    pa = parse_pack_size(a)
    pb = parse_pack_size(b)

    if pa.value is None or pb.value is None:
        return AttributeResult.UNKNOWN

    if pa.unit != pb.unit:
        return AttributeResult.MISMATCH

    return AttributeResult.MATCH if abs(pa.value - pb.value) < 1e-6 else AttributeResult.MISMATCH


def compare_strength_type(a: Optional[str], b: Optional[str]) -> AttributeResult:
    """Compare two strength-type / formulation strings."""
    na = normalise_strength_type(a)
    nb = normalise_strength_type(b)

    if na is None or nb is None:
        return AttributeResult.UNKNOWN

    return AttributeResult.MATCH if na == nb else AttributeResult.MISMATCH


# ---------------------------------------------------------------------------
# Combined attribute check
# ---------------------------------------------------------------------------
@dataclass
class AttributeCheckResult:
    strength: AttributeResult
    pack_size: AttributeResult
    strength_type: AttributeResult
    has_conflict: bool
    summary: str  # human-readable


def check_attributes(
    input_strength: Optional[str],
    input_pack_size: Optional[str],
    input_strength_type: Optional[str],
    candidate_strength: Optional[str],
    candidate_pack_size: Optional[str],
    candidate_strength_type: Optional[str],
    block_on_strength: bool = True,
    block_on_strength_type: bool = True,
    block_on_pack_size: bool = False,
) -> AttributeCheckResult:
    """
    Compare input attributes against a candidate's master attributes.

    Returns an AttributeCheckResult with individual results and a conflict flag.
    A conflict is raised only when a blocking attribute shows MISMATCH.
    UNKNOWN is never a conflict.
    """
    s_res = compare_strength(input_strength, candidate_strength)
    p_res = compare_pack_size(input_pack_size, candidate_pack_size)
    t_res = compare_strength_type(input_strength_type, candidate_strength_type)

    conflict = (
        (block_on_strength and s_res == AttributeResult.MISMATCH)
        or (block_on_strength_type and t_res == AttributeResult.MISMATCH)
        or (block_on_pack_size and p_res == AttributeResult.MISMATCH)
    )

    parts = []
    for label, res in [("Strength", s_res), ("PackSize", p_res), ("StrengthType", t_res)]:
        parts.append(f"{label}={res.value}")
    summary = "; ".join(parts)

    return AttributeCheckResult(
        strength=s_res,
        pack_size=p_res,
        strength_type=t_res,
        has_conflict=conflict,
        summary=summary,
    )
