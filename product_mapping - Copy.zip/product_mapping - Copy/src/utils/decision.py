"""
utils/decision.py
-----------------
Decision policy: AUTO_MATCH / REVIEW / UNMATCHED

Rules (all must pass for AUTO_MATCH):
  1. Top candidate score >= auto_match_min_score
  2. Gap between top and second candidate >= auto_match_min_gap
  3. Top candidate product code exists in the approved master
  4. No blocking attribute conflict

REVIEW: a plausible candidate exists but one of the rules above fails.
UNMATCHED: no candidate meets the review_min_score threshold.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class Decision(str, Enum):
    AUTO_MATCH = "AUTO_MATCH"
    REVIEW = "REVIEW"
    UNMATCHED = "UNMATCHED"


@dataclass
class DecisionResult:
    decision: Decision
    reason: str
    top_score: float
    second_score: float
    predicted_code: Optional[str]
    predicted_name: Optional[str]
    attribute_check_status: str


def make_decision(
    top_score: float,
    second_score: float,
    top_code: Optional[str],
    top_name: Optional[str],
    approved_codes: set,
    has_attribute_conflict: bool,
    attribute_summary: str,
    auto_match_min_score: float = 0.60,
    auto_match_min_gap: float = 0.10,
    review_min_score: float = 0.20,
) -> DecisionResult:
    """
    Apply the decision policy and return a DecisionResult.

    Parameters
    ----------
    top_score : similarity score of the best candidate (0–1).
    second_score : similarity score of the second-best candidate.
    top_code : Abbott product code of the best candidate.
    top_name : Abbott product name of the best candidate.
    approved_codes : set of all product codes in the approved master.
    has_attribute_conflict : True if a blocking attribute contradiction was found.
    attribute_summary : human-readable attribute comparison string.
    """

    # No viable candidate
    if top_score < review_min_score or top_code is None:
        return DecisionResult(
            decision=Decision.UNMATCHED,
            reason="No candidate met the minimum score threshold.",
            top_score=top_score,
            second_score=second_score,
            predicted_code=None,
            predicted_name=None,
            attribute_check_status=attribute_summary,
        )

    # Code not in approved master
    if top_code not in approved_codes:
        return DecisionResult(
            decision=Decision.REVIEW,
            reason=f"Top candidate code '{top_code}' not in the approved master.",
            top_score=top_score,
            second_score=second_score,
            predicted_code=top_code,
            predicted_name=top_name,
            attribute_check_status=attribute_summary,
        )

    # Attribute conflict
    if has_attribute_conflict:
        return DecisionResult(
            decision=Decision.REVIEW,
            reason=f"Attribute conflict detected: {attribute_summary}",
            top_score=top_score,
            second_score=second_score,
            predicted_code=top_code,
            predicted_name=top_name,
            attribute_check_status=attribute_summary,
        )

    # Score too low for auto-match
    if top_score < auto_match_min_score:
        return DecisionResult(
            decision=Decision.REVIEW,
            reason=f"Score {top_score:.3f} below auto-match threshold {auto_match_min_score}.",
            top_score=top_score,
            second_score=second_score,
            predicted_code=top_code,
            predicted_name=top_name,
            attribute_check_status=attribute_summary,
        )

    # Score gap too small (ambiguous)
    gap = top_score - second_score
    if gap < auto_match_min_gap:
        return DecisionResult(
            decision=Decision.REVIEW,
            reason=(
                f"Score gap {gap:.3f} between top candidates below minimum {auto_match_min_gap}. "
                "Input may be ambiguous."
            ),
            top_score=top_score,
            second_score=second_score,
            predicted_code=top_code,
            predicted_name=top_name,
            attribute_check_status=attribute_summary,
        )

    # All checks passed
    return DecisionResult(
        decision=Decision.AUTO_MATCH,
        reason="All validation criteria met.",
        top_score=top_score,
        second_score=second_score,
        predicted_code=top_code,
        predicted_name=top_name,
        attribute_check_status=attribute_summary,
    )
