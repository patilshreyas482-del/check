"""
utils/config.py
---------------
Load and expose the central YAML configuration.
"""
from pathlib import Path
import yaml

_DEFAULT_CONFIG_PATH = Path(__file__).resolve().parents[2] / "config" / "settings.yaml"


def load_config(config_path: str | Path | None = None) -> dict:
    """Load YAML config. Uses default path if none supplied."""
    path = Path(config_path) if config_path else _DEFAULT_CONFIG_PATH
    with open(path, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    return cfg
