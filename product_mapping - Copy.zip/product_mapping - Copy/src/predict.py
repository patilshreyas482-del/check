"""
src/predict.py
--------------
Phase 7 – Production inference CLI.

Usage via CLI wrapper:
    python src/06_predict.py --name "ALPHA CARE 10MG TABS 10S" --sample
    python src/06_predict.py --input data/raw/new_inputs.csv
"""

import sys
import argparse
import csv
from datetime import datetime
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.config import load_config
from src.utils.text_norm import build_alias_map_from_config
from src.build_baseline import predict_one, load_model, build_and_save
from src.prepare_master import prepare_master


OUTPUT_COLS = [
    "timestamp", "stockist_code", "stockist_given_product_name",
    "predicted_company_product_code", "predicted_company_product_name",
    "decision", "top_candidate_score", "second_candidate_score",
    "attribute_check_status", "review_reason", "model_version", "master_version",
]


def _load_or_build_model(cfg: dict, master_path: Path = None):
    try:
        return load_model(cfg)
    except FileNotFoundError:
        print("⚠️  No saved model found. Building baseline model now…")
        if master_path is None:
            master_path = ROOT / cfg["paths"]["master_file"]
        build_and_save(master_path, cfg)
        return load_model(cfg)


def predict_batch(names, stockist_codes, retriever, approved_codes, alias_map, cfg):
    results = []
    for name, sc in zip(names, stockist_codes):
        row = predict_one(name, retriever, approved_codes, alias_map, cfg)
        row["stockist_code"] = sc
        row["timestamp"] = datetime.now().isoformat(timespec="seconds")
        results.append(row)
    return pd.DataFrame(results)


def _append_log(df: pd.DataFrame, log_path: Path):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not log_path.exists()
    df[OUTPUT_COLS].to_csv(log_path, mode="a", index=False,
                            header=write_header, quoting=csv.QUOTE_ALL)


def _print_result(row: dict):
    dec = row["decision"]
    colour = {"AUTO_MATCH": "\033[92m", "REVIEW": "\033[93m", "UNMATCHED": "\033[91m"}.get(dec, "")
    reset  = "\033[0m"
    print(f"\n{'─'*60}")
    print(f"  Input:     {row['stockist_given_product_name']}")
    print(f"  Decision:  {colour}{dec}{reset}")
    print(f"  Code:      {row['predicted_company_product_code'] or '—'}")
    print(f"  Name:      {row['predicted_company_product_name'] or '—'}")
    print(f"  Score:     {row['top_candidate_score']}  (2nd: {row['second_candidate_score']})")
    print(f"  Attrs:     {row['attribute_check_status'] or '—'}")
    print(f"  Reason:    {row['review_reason']}")
    print(f"{'─'*60}")


def main():
    parser = argparse.ArgumentParser(description="Predict Abbott product code for stockist name(s).")
    parser.add_argument("--name", default=None)
    parser.add_argument("--stockist", default="")
    parser.add_argument("--input", default=None)
    parser.add_argument("--name-col", default="stockist_given_product_name")
    parser.add_argument("--stockist-col", default="stockist_code")
    parser.add_argument("--master", default=None)
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--no-log", action="store_true")
    parser.add_argument("--config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    alias_map = build_alias_map_from_config(cfg)

    master_path = (
        ROOT / cfg["paths"]["sample_master"] if args.sample
        else (Path(args.master) if args.master else ROOT / cfg["paths"]["master_file"])
    )

    retriever, master_df, approved_codes = _load_or_build_model(cfg, master_path)

    if args.name:
        names = [args.name]
        stockist_codes = [args.stockist]
    elif args.input:
        input_df = pd.read_csv(args.input, dtype=str, keep_default_na=False)
        names = input_df[args.name_col].tolist()
        stockist_codes = (
            input_df[args.stockist_col].tolist()
            if args.stockist_col in input_df.columns else [""] * len(names)
        )
    else:
        parser.print_help()
        sys.exit(1)

    result_df = predict_batch(names, stockist_codes, retriever, approved_codes, alias_map, cfg)

    for _, row in result_df.iterrows():
        _print_result(row.to_dict())

    if not args.no_log:
        log_path = ROOT / cfg["paths"]["predictions_log"]
        _append_log(result_df, log_path)
        print(f"\n📋  Results appended to: {log_path}")


if __name__ == "__main__":
    main()
