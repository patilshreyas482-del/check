"""
src/evaluate.py
---------------
Phase 5 – Comprehensive evaluation on a locked test set.

Usage via CLI wrapper:
    python src/05_evaluate.py [--sample]
"""

import sys
import argparse
from pathlib import Path

import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.config import load_config
from src.utils.text_norm import normalise_series, build_alias_map_from_config
from src.build_baseline import TFIDFRetriever, predict_one, load_model
from src.prepare_master import prepare_master


def evaluate(hist_path: Path, master_path: Path, cfg: dict) -> pd.DataFrame:
    hcols = cfg["historical_columns"]
    alias_map = build_alias_map_from_config(cfg)

    hist = pd.read_csv(hist_path, dtype=str, keep_default_na=False)
    sn_col = hcols["stockist_name"]
    cc_col = hcols["company_code"]
    sc_col = hcols["stockist_code"]

    hist = hist.dropna(subset=[sn_col, cc_col])
    hist["_norm_name"] = normalise_series(hist[sn_col], alias_map=alias_map)

    unique_names = hist["_norm_name"].dropna().unique()
    np.random.seed(42)
    np.random.shuffle(unique_names)
    split_idx = int(len(unique_names) * 0.8)
    test_names = set(unique_names[split_idx:])
    hist_test = hist[hist["_norm_name"].isin(test_names)]

    if hist_test.empty:
        print("⚠️  No test rows after split. Using full dataset.")
        hist_test = hist

    try:
        retriever, master_df, approved_codes = load_model(cfg)
        print("Loaded saved model.")
    except FileNotFoundError:
        print("No saved model found. Building baseline on the fly…")
        master_df = prepare_master(master_path, cfg)
        mcols = cfg["master_columns"]
        retrieval_cfg = cfg["retrieval"]
        retriever = TFIDFRetriever(
            master_df=master_df, mcols=mcols,
            ngram_range=tuple(retrieval_cfg["tfidf_ngram_range"]),
            analyzer=retrieval_cfg["tfidf_analyzer"],
            top_k=retrieval_cfg["top_k"],
            min_sim=retrieval_cfg["min_similarity_threshold"],
        )
        approved_codes = set(master_df[mcols["product_code"]].dropna().astype(str))

    results = []
    print(f"\nEvaluating {len(hist_test)} test rows…")
    for _, row in hist_test.iterrows():
        pred = predict_one(row[sn_col], retriever, approved_codes, alias_map, cfg)
        pred["true_company_code"] = row[cc_col]
        pred["stockist_code"] = row.get(sc_col, "")
        pred["correct"] = pred["predicted_company_product_code"] == row[cc_col]
        results.append(pred)

    return pd.DataFrame(results)


def compute_metrics(df: pd.DataFrame) -> dict:
    n = len(df)
    auto     = df[df["decision"] == "AUTO_MATCH"]
    review   = df[df["decision"] == "REVIEW"]
    unmatched = df[df["decision"] == "UNMATCHED"]
    return {
        "Total test rows": n,
        "Top-1 accuracy (all)": f"{df['correct'].mean():.1%}",
        "Auto-match count": len(auto),
        "Auto-match coverage": f"{len(auto)/n:.1%}",
        "Auto-match precision": f"{auto['correct'].mean():.1%}" if len(auto) > 0 else "N/A",
        "Review count": len(review),
        "Review rate": f"{len(review)/n:.1%}",
        "Unmatched count": len(unmatched),
        "Unmatched rate": f"{len(unmatched)/n:.1%}",
    }


def _html_metrics(metrics: dict) -> str:
    rows = "".join(
        f"<tr><td style='padding:6px 14px;border:1px solid #ddd'><b>{k}</b></td>"
        f"<td style='padding:6px 14px;border:1px solid #ddd'>{v}</td></tr>"
        for k, v in metrics.items()
    )
    return (
        f"<h3 style='font-family:Arial;color:#2c3e50'>Evaluation Metrics</h3>"
        f"<table style='border-collapse:collapse;font-family:Arial;font-size:13px'>"
        f"<tbody>{rows}</tbody></table><br/>"
    )


def main():
    parser = argparse.ArgumentParser(description="Evaluate the mapping model.")
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--historical", default=None)
    parser.add_argument("--master", default=None)
    parser.add_argument("--config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    if args.sample:
        hist_path   = ROOT / cfg["paths"]["sample_historical"]
        master_path = ROOT / cfg["paths"]["sample_master"]
    else:
        hist_path   = Path(args.historical) if args.historical else ROOT / cfg["paths"]["historical_file"]
        master_path = Path(args.master)     if args.master     else ROOT / cfg["paths"]["master_file"]

    results_df = evaluate(hist_path, master_path, cfg)
    metrics = compute_metrics(results_df)
    for k, v in metrics.items():
        print(f"  {k}: {v}")

    report_dir = ROOT / cfg["paths"]["reports_dir"]
    report_dir.mkdir(parents=True, exist_ok=True)
    html = (
        "<!DOCTYPE html><html><head><meta charset='utf-8'/>"
        "<title>Evaluation Report</title></head>"
        "<body style='max-width:1100px;margin:40px auto;font-family:Arial'>"
        "<h1 style='color:#2c3e50'>Product Mapping — Evaluation Report</h1>"
        + _html_metrics(metrics)
        + "<h3 style='color:#2c3e50'>Detailed Results (sample)</h3>"
        + results_df.head(50).to_html(index=False)
        + "</body></html>"
    )
    report_path = report_dir / "evaluation_report.html"
    report_path.write_text(html, encoding="utf-8")
    print(f"\n✅  Evaluation report saved to: {report_path}")


if __name__ == "__main__":
    main()
