"""
src/profile_data.py
-------------------
Phase 1 – Data quality report.

Usage via CLI wrapper:
    python src/01_profile_data.py [--sample]
"""

import sys
import argparse
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.config import load_config
from src.utils.text_norm import normalise_series, build_alias_map_from_config


def load_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def _html_table(df: pd.DataFrame, title: str = "") -> str:
    style    = "border-collapse:collapse;width:100%;font-family:Arial,sans-serif;font-size:13px;"
    th_style = "background:#2c3e50;color:#fff;padding:8px 12px;text-align:left;border:1px solid #ccc;"
    td_style = "padding:6px 12px;border:1px solid #ddd;"
    alt_style = "background:#f4f6f8;"

    rows_html = []
    for i, (_, row) in enumerate(df.iterrows()):
        row_style = alt_style if i % 2 == 0 else ""
        cells = "".join(f'<td style="{td_style}{row_style}">{v}</td>' for v in row.values)
        rows_html.append(f"<tr>{cells}</tr>")

    header    = "".join(f'<th style="{th_style}">{c}</th>' for c in df.columns)
    title_html = f"<h3 style='font-family:Arial;color:#2c3e50'>{title}</h3>" if title else ""
    return (
        f"{title_html}<table style='{style}'><thead><tr>{header}</tr></thead>"
        f"<tbody>{''.join(rows_html)}</tbody></table><br/>"
    )


def _missing_pct(series: pd.Series, missing_tokens: set) -> float:
    cleaned = series.str.strip().str.upper()
    return round(100 * cleaned.isin(missing_tokens).mean(), 2)


def profile(hist_path: Path, master_path: Path, cfg: dict, output_path: Path) -> None:
    hcols = cfg["historical_columns"]
    mcols = cfg["master_columns"]
    missing_tokens = {t.upper() for t in cfg["missing_tokens"]}
    alias_map = build_alias_map_from_config(cfg)

    print(f"Loading historical file: {hist_path}")
    hist = load_csv(hist_path)
    print(f"Loading master file:     {master_path}")
    master = load_csv(master_path)

    sections = ["<h1 style='font-family:Arial;color:#2c3e50'>Product Mapping — Data Quality Report</h1>"]

    count_data = {"File": ["Historical mapping", "Product master"],
                  "Rows": [len(hist), len(master)],
                  "Columns": [hist.shape[1], master.shape[1]]}
    sections.append(_html_table(pd.DataFrame(count_data), "1. File Overview"))

    hist_null = pd.DataFrame({
        "Column": list(hcols.keys()), "Mapped to": list(hcols.values()),
        "Missing / Empty (%)": [
            _missing_pct(hist[v], missing_tokens) if v in hist.columns else "COLUMN NOT FOUND"
            for v in hcols.values()
        ],
    })
    sections.append(_html_table(hist_null, "2. Historical File — Missing Values"))

    master_null = pd.DataFrame({
        "Column": list(mcols.keys()), "Mapped to": list(mcols.values()),
        "Missing / Empty (%)": [
            _missing_pct(master[v], missing_tokens) if v in master.columns else "COLUMN NOT FOUND"
            for v in mcols.values()
        ],
    })
    sections.append(_html_table(master_null, "3. Master File — Missing Values"))

    sc_col = hcols["stockist_code"]; sn_col = hcols["stockist_name"]
    cc_col = hcols["company_code"];  cn_col = hcols["company_name"]
    pc_col = mcols["product_code"];  pn_col = mcols["product_name"]

    def safe_nunique(df, col):
        return df[col].nunique() if col in df.columns else "N/A"

    unique_data = {
        "Metric": ["Unique stockist codes", "Unique stockist-given product names",
                   "Unique company product codes (historical)", "Unique company product names (historical)",
                   "Unique product codes (master)", "Unique product names (master)"],
        "Count": [safe_nunique(hist, sc_col), safe_nunique(hist, sn_col),
                  safe_nunique(hist, cc_col), safe_nunique(hist, cn_col),
                  safe_nunique(master, pc_col), safe_nunique(master, pn_col)],
    }
    sections.append(_html_table(pd.DataFrame(unique_data), "4. Unique Value Counts"))

    if pc_col in master.columns:
        dup_codes = master[master.duplicated(subset=[pc_col], keep=False)]
        dup_count = dup_codes[pc_col].nunique()
        sections.append(f"<h3 style='font-family:Arial;color:#2c3e50'>5. Duplicate Product Codes in Master</h3>"
                        f"<p style='font-family:Arial'>Codes with > 1 master row: <b>{dup_count}</b></p>")
        if dup_count > 0:
            sections.append(_html_table(dup_codes.head(20), "Duplicate Master Rows (sample)"))

    if sn_col in hist.columns and cc_col in hist.columns:
        hist["_norm_name"] = normalise_series(hist[sn_col], alias_map=alias_map)
        conflict = (hist.groupby("_norm_name")[cc_col].nunique()
                    .reset_index().rename(columns={cc_col: "distinct_codes"}))
        conflict_multi = conflict[conflict["distinct_codes"] > 1].sort_values("distinct_codes", ascending=False)
        sections.append(f"<h3 style='font-family:Arial;color:#2c3e50'>6. Conflicting Labels</h3>"
                        f"<p style='font-family:Arial'>Names mapping to > 1 code: <b>{len(conflict_multi)}</b></p>")
        if len(conflict_multi) > 0:
            sections.append(_html_table(conflict_multi.head(30), "Conflicting Label Sample"))

    if cc_col in hist.columns and pc_col in master.columns:
        hist_codes   = set(hist[cc_col].str.strip().unique())
        master_codes = set(master[pc_col].str.strip().unique())
        absent = hist_codes - master_codes
        sections.append(f"<h3 style='font-family:Arial;color:#2c3e50'>7. Historical Codes Absent from Master</h3>"
                        f"<p style='font-family:Arial'>Absent codes: <b>{len(absent)}</b> / {len(hist_codes)}"
                        f" ({round(100*len(absent)/max(len(hist_codes),1),1)}%)</p>")
        if absent:
            sections.append(_html_table(pd.DataFrame({"absent_code": sorted(absent)}).head(30), "Sample Absent Codes"))

    if cc_col in hist.columns and cn_col in hist.columns:
        inconsistent = (hist.groupby(cc_col)[cn_col].nunique()
                        .reset_index().rename(columns={cn_col: "distinct_names"}))
        inconsistent = inconsistent[inconsistent["distinct_names"] > 1]
        sections.append(f"<h3 style='font-family:Arial;color:#2c3e50'>8. Codes with Multiple Company Names</h3>"
                        f"<p style='font-family:Arial'>Codes with > 1 name: <b>{len(inconsistent)}</b></p>")
        if len(inconsistent) > 0:
            sections.append(_html_table(inconsistent.head(20), "Inconsistent Code-Name Pairs"))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    html = ("<!DOCTYPE html><html><head><meta charset='utf-8'/><title>Data Quality Report</title></head>"
            "<body style='max-width:1100px;margin:40px auto;'>" + "".join(sections) + "</body></html>")
    output_path.write_text(html, encoding="utf-8")
    print(f"\n✅  Report written to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Profile historical mapping + master data.")
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--historical", default=None)
    parser.add_argument("--master", default=None)
    parser.add_argument("--config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    if args.sample:
        hist_path   = ROOT / cfg["paths"]["sample_historical"]
        master_path = ROOT / cfg["paths"]["sample_master"]
    else:
        hist_path   = Path(args.historical) if args.historical else ROOT / cfg["paths"]["historical_file"]
        master_path = Path(args.master)     if args.master     else ROOT / cfg["paths"]["master_file"]

    output_path = ROOT / cfg["paths"]["reports_dir"] / "data_quality_report.html"
    profile(hist_path, master_path, cfg, output_path)


if __name__ == "__main__":
    main()
