"""CLI entry-point for Phase 4. Logic lives in src/train_model.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.train_model import main
if __name__ == "__main__":
    main()
