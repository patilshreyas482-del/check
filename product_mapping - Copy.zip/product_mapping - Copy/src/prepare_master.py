"""
src/prepare_master.py
---------------------
Phase 2 – Normalise and cache the product master.

Usage:
    python src/02_prepare_master.py [--sample]
    python src/02_prepare_master.py --master data/raw/product_master.csv

Output:
    data/interim/master_prepared.csv
"""

import sys
import argparse
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.config import load_config
from src.utils.text_norm import normalise_series, build_alias_map_from_config
from src.utils.attributes import parse_strength, parse_pack_size, normalise_strength_type


MISSING_TOKENS = {"N/A", "NA", "NULL", "NONE", "NIL", "", "-", "--"}


def _as_missing(series: pd.Series) -> pd.Series:
    """Replace recognised missing tokens with pd.NA."""
    cleaned = series.str.strip().str.upper()
    return series.where(~cleaned.isin(MISSING_TOKENS), other=pd.NA)


def prepare_master(master_path: Path, cfg: dict) -> pd.DataFrame:
    mcols = cfg["master_columns"]
    alias_map = build_alias_map_from_config(cfg)

    print(f"Loading master: {master_path}")
    df = pd.read_csv(master_path, dtype=str, keep_default_na=False)

    pc = mcols["product_code"]
    pn = mcols["product_name"]
    ps = mcols["pack_size"]
    st = mcols["strength"]
    sty = mcols["strength_type"]

    for col in [pc, pn, ps, st, sty]:
        if col in df.columns:
            df[col] = _as_missing(df[col])

    df["product_name_norm"] = normalise_series(df[pn].fillna(""), alias_map=alias_map)

    df["strength_value"] = df[st].apply(
        lambda x: parse_strength(x).value if pd.notna(x) else None
    )
    df["strength_unit"] = df[st].apply(
        lambda x: parse_strength(x).unit if pd.notna(x) else None
    )
    df["pack_size_value"] = df[ps].apply(
        lambda x: parse_pack_size(x).value if pd.notna(x) else None
    )
    df["pack_size_unit"] = df[ps].apply(
        lambda x: parse_pack_size(x).unit if pd.notna(x) else None
    )
    df["strength_type_norm"] = df[sty].apply(
        lambda x: normalise_strength_type(x) if pd.notna(x) else None
    )

    print(f"  → {len(df)} master rows prepared.")
    print(f"  → Unique product codes: {df[pc].nunique()}")
    return df


def main():
    parser = argparse.ArgumentParser(description="Normalise and cache the product master.")
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--master", default=None)
    parser.add_argument("--config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)

    if args.sample:
        master_path = ROOT / cfg["paths"]["sample_master"]
    else:
        master_path = (
            Path(args.master) if args.master else ROOT / cfg["paths"]["master_file"]
        )

    df = prepare_master(master_path, cfg)

    out_path = ROOT / cfg["paths"]["master_prepared"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"\n✅  Prepared master saved to: {out_path}")


if __name__ == "__main__":
    main()
