"""
src/train_model.py
------------------
Phase 4 – Train a supervised candidate-ranking model on historical labels.

Usage via CLI wrapper:
    python src/04_train_model.py [--sample]
"""

import sys
import argparse
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.config import load_config
from src.utils.text_norm import normalise_series, build_alias_map_from_config
from src.utils.attributes import check_attributes, AttributeResult
from src.prepare_master import prepare_master
from src.build_baseline import TFIDFRetriever
from src.utils.text_norm import normalise


ATTR_SCORE = {
    AttributeResult.MATCH: 1.0,
    AttributeResult.UNKNOWN: 0.5,
    AttributeResult.MISMATCH: 0.0,
}

FEATURE_COLS = [
    "tfidf_score", "rank", "strength_score", "pack_size_score", "strength_type_score"
]


def build_features(raw_name, target_code, retriever, alias_map, cfg):
    mcols = cfg["master_columns"]
    norm_name = normalise(raw_name, alias_map=alias_map) or ""
    candidates = retriever.retrieve(norm_name)

    rows = []
    for rank, (_, cand) in enumerate(candidates.iterrows()):
        attr = check_attributes(
            input_strength=None, input_pack_size=None, input_strength_type=None,
            candidate_strength=cand.get(mcols["strength"]),
            candidate_pack_size=cand.get(mcols["pack_size"]),
            candidate_strength_type=cand.get(mcols["strength_type"]),
        )
        rows.append({
            "tfidf_score": float(cand["score"]),
            "rank": rank,
            "strength_score": ATTR_SCORE[attr.strength],
            "pack_size_score": ATTR_SCORE[attr.pack_size],
            "strength_type_score": ATTR_SCORE[attr.strength_type],
            "label": int(str(cand[mcols["product_code"]]) == str(target_code)),
            "_candidate_code": str(cand[mcols["product_code"]]),
        })
    return rows


def train(hist_path: Path, master_path: Path, cfg: dict):
    hcols = cfg["historical_columns"]
    alias_map = build_alias_map_from_config(cfg)

    print(f"Loading historical file: {hist_path}")
    hist = pd.read_csv(hist_path, dtype=str, keep_default_na=False)

    sn_col = hcols["stockist_name"]
    cc_col = hcols["company_code"]

    hist = hist.dropna(subset=[sn_col, cc_col])
    hist = hist[hist[sn_col].str.strip() != ""]
    hist = hist[hist[cc_col].str.strip() != ""]
    hist["_norm_name"] = normalise_series(hist[sn_col], alias_map=alias_map)

    master_df = prepare_master(master_path, cfg)
    mcols = cfg["master_columns"]
    retrieval_cfg = cfg["retrieval"]
    retriever = TFIDFRetriever(
        master_df=master_df, mcols=mcols,
        ngram_range=tuple(retrieval_cfg["tfidf_ngram_range"]),
        analyzer=retrieval_cfg["tfidf_analyzer"],
        top_k=retrieval_cfg["top_k"],
        min_sim=retrieval_cfg["min_similarity_threshold"],
    )

    unique_names = hist["_norm_name"].dropna().unique()
    np.random.seed(42)
    np.random.shuffle(unique_names)
    split_idx = int(len(unique_names) * 0.8)
    train_names = set(unique_names[:split_idx])
    test_names  = set(unique_names[split_idx:])

    hist_train = hist[hist["_norm_name"].isin(train_names)]
    hist_test  = hist[hist["_norm_name"].isin(test_names)]
    print(f"Train names: {len(train_names)} | Test names: {len(test_names)}")
    print(f"Train rows:  {len(hist_train)} | Test rows:  {len(hist_test)}")

    def build_dataset(subset):
        all_rows = []
        for _, row in subset.iterrows():
            all_rows.extend(build_features(row[sn_col], row[cc_col], retriever, alias_map, cfg))
        return pd.DataFrame(all_rows)

    print("\nBuilding training features…")
    train_df = build_dataset(hist_train)
    print("Building test features…")
    test_df = build_dataset(hist_test)

    if train_df["label"].nunique() < 2:
        print("⚠️  Not enough positive labels to train. Use larger dataset.")
        return

    clf = LogisticRegression(max_iter=1000, class_weight="balanced")
    clf.fit(train_df[FEATURE_COLS], train_df["label"])

    test_preds = clf.predict(test_df[FEATURE_COLS])
    print("\n── Test Set Classification Report ──")
    print(classification_report(test_df["label"], test_preds))

    model_dir = ROOT / cfg["paths"]["models_dir"]
    model_dir.mkdir(parents=True, exist_ok=True)
    approved_codes = set(master_df[mcols["product_code"]].dropna().astype(str))

    with open(model_dir / "tfidf_baseline.pkl", "wb") as f:
        pickle.dump({
            "retriever": retriever, "master_df": master_df,
            "approved_codes": approved_codes, "ranker": clf,
        }, f)
    print(f"\n✅  Supervised model saved to: {model_dir / 'tfidf_baseline.pkl'}")


def main():
    parser = argparse.ArgumentParser(description="Train supervised ranking model.")
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--historical", default=None)
    parser.add_argument("--master", default=None)
    parser.add_argument("--config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    if args.sample:
        hist_path   = ROOT / cfg["paths"]["sample_historical"]
        master_path = ROOT / cfg["paths"]["sample_master"]
    else:
        hist_path   = Path(args.historical) if args.historical else ROOT / cfg["paths"]["historical_file"]
        master_path = Path(args.master)     if args.master     else ROOT / cfg["paths"]["master_file"]

    train(hist_path, master_path, cfg)


if __name__ == "__main__":
    main()
