"""CLI entry-point for Phase 1. Logic lives in src/profile_data.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.profile_data import main
if __name__ == "__main__":
    main()
