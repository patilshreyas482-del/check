"""CLI entry-point for Phase 2. Logic lives in src/prepare_master.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.prepare_master import main
if __name__ == "__main__":
    main()
