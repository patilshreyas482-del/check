"""CLI entry-point for Phase 6 (inference). Logic lives in src/predict.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.predict import main
if __name__ == "__main__":
    main()
