"""
src/build_baseline.py
---------------------
Phase 3 – Build and save the TF-IDF character n-gram baseline retriever.

Usage:
    python src/03_build_baseline.py [--sample]
    python src/03_build_baseline.py --master data/raw/product_master.csv

Outputs:
    outputs/models/tfidf_baseline.pkl
    outputs/reports/baseline_eval.html
"""

import sys
import argparse
import pickle
from pathlib import Path

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.config import load_config
from src.utils.text_norm import normalise, build_alias_map_from_config
from src.utils.attributes import check_attributes
from src.utils.decision import make_decision, Decision
from src.prepare_master import prepare_master


# ── Retriever class ────────────────────────────────────────────────────────────

class TFIDFRetriever:
    """TF-IDF character n-gram retriever over normalised master product names."""

    def __init__(self, master_df, mcols, ngram_range=(2, 4),
                 analyzer="char_wb", top_k=5, min_sim=0.05):
        self.master_df = master_df.reset_index(drop=True)
        self.mcols = mcols
        self.top_k = top_k
        self.min_sim = min_sim

        self.vectoriser = TfidfVectorizer(
            analyzer=analyzer, ngram_range=ngram_range, lowercase=False
        )
        corpus = master_df["product_name_norm"].fillna("").tolist()
        self.matrix = self.vectoriser.fit_transform(corpus)

    def retrieve(self, query_norm: str) -> pd.DataFrame:
        qvec = self.vectoriser.transform([query_norm])
        sims = cosine_similarity(qvec, self.matrix).flatten()
        top_idx = np.argsort(sims)[::-1][: self.top_k]
        candidates = self.master_df.iloc[top_idx].copy()
        candidates["score"] = sims[top_idx]
        candidates = candidates[candidates["score"] >= self.min_sim]
        return candidates.reset_index(drop=True)


# ── Single-name prediction ─────────────────────────────────────────────────────

def predict_one(raw_name, retriever, approved_codes, alias_map, cfg,
                raw_strength=None, raw_pack_size=None, raw_strength_type=None):
    dec_cfg = cfg["decision"]
    mcols = cfg["master_columns"]

    norm_name = normalise(raw_name, alias_map=alias_map) or ""
    candidates = retriever.retrieve(norm_name)

    if candidates.empty:
        from src.utils.decision import DecisionResult
        result = DecisionResult(
            decision=Decision.UNMATCHED,
            reason="No candidates retrieved.",
            top_score=0.0, second_score=0.0,
            predicted_code=None, predicted_name=None,
            attribute_check_status="",
        )
    else:
        top = candidates.iloc[0]
        second_score = candidates.iloc[1]["score"] if len(candidates) > 1 else 0.0

        attr_result = check_attributes(
            input_strength=raw_strength,
            input_pack_size=raw_pack_size,
            input_strength_type=raw_strength_type,
            candidate_strength=top.get(mcols["strength"]),
            candidate_pack_size=top.get(mcols["pack_size"]),
            candidate_strength_type=top.get(mcols["strength_type"]),
            block_on_strength=dec_cfg.get("block_on_strength_conflict", True),
            block_on_strength_type=dec_cfg.get("block_on_strength_type_conflict", True),
            block_on_pack_size=dec_cfg.get("block_on_packsize_conflict", False),
        )

        result = make_decision(
            top_score=float(top["score"]),
            second_score=float(second_score),
            top_code=str(top[mcols["product_code"]]),
            top_name=str(top[mcols["product_name"]]),
            approved_codes=approved_codes,
            has_attribute_conflict=attr_result.has_conflict,
            attribute_summary=attr_result.summary,
            auto_match_min_score=dec_cfg["auto_match_min_score"],
            auto_match_min_gap=dec_cfg["auto_match_min_gap"],
            review_min_score=dec_cfg["review_min_score"],
        )

    return {
        "stockist_given_product_name": raw_name,
        "predicted_company_product_code": result.predicted_code,
        "predicted_company_product_name": result.predicted_name,
        "decision": result.decision.value,
        "top_candidate_score": round(result.top_score, 4),
        "second_candidate_score": round(result.second_score, 4),
        "attribute_check_status": result.attribute_check_status,
        "review_reason": result.reason,
        "model_version": cfg["model"]["version"],
        "master_version": cfg["model"]["master_version"],
    }


# ── Build + save ───────────────────────────────────────────────────────────────

def build_and_save(master_path: Path, cfg: dict):
    master_df = prepare_master(master_path, cfg)
    mcols = cfg["master_columns"]
    retrieval_cfg = cfg["retrieval"]

    retriever = TFIDFRetriever(
        master_df=master_df, mcols=mcols,
        ngram_range=tuple(retrieval_cfg["tfidf_ngram_range"]),
        analyzer=retrieval_cfg["tfidf_analyzer"],
        top_k=retrieval_cfg["top_k"],
        min_sim=retrieval_cfg["min_similarity_threshold"],
    )

    model_dir = ROOT / cfg["paths"]["models_dir"]
    model_dir.mkdir(parents=True, exist_ok=True)
    model_path = model_dir / "tfidf_baseline.pkl"

    approved_codes = set(master_df[mcols["product_code"]].dropna().astype(str))
    with open(model_path, "wb") as f:
        pickle.dump({"retriever": retriever, "master_df": master_df,
                     "approved_codes": approved_codes}, f)
    print(f"\n✅  Baseline model saved to: {model_path}")
    return retriever, master_df, approved_codes


def load_model(cfg: dict):
    model_path = ROOT / cfg["paths"]["models_dir"] / "tfidf_baseline.pkl"
    with open(model_path, "rb") as f:
        obj = pickle.load(f)
    return obj["retriever"], obj["master_df"], obj["approved_codes"]


def evaluate_sample(retriever, master_df, approved_codes, cfg):
    alias_map = build_alias_map_from_config(cfg)
    test_cases = [
        ("ALPHA CARE 10MG TABS 10'S", "DEMO001", "AUTO_MATCH or REVIEW"),
        ("BETA MINT LIQ 100ML",        "DEMO002", "AUTO_MATCH or REVIEW"),
        ("ALPHA CARE 10 MG TABLETS 10S","DEMO001", "AUTO_MATCH"),
        ("ALPHA CARE TABLETS",          None,      "REVIEW"),
        ("UNKNOWN BRAND 999 MG",        None,      "UNMATCHED"),
    ]
    rows = []
    for raw, expected_code, expected_decision in test_cases:
        res = predict_one(raw, retriever, approved_codes, alias_map, cfg)
        rows.append({
            "Input": raw,
            "Predicted Code": res["predicted_company_product_code"] or "—",
            "Decision": res["decision"],
            "Score": res["top_candidate_score"],
            "Expected Code": expected_code or "—",
            "Expected Behaviour": expected_decision,
            "Reason": res["review_reason"],
        })
    results_df = pd.DataFrame(rows)
    print("\n── Sample Evaluation ──────────────────────────────────────────")
    print(results_df[["Input", "Predicted Code", "Decision", "Score"]].to_string(index=False))
    return results_df


def main():
    parser = argparse.ArgumentParser(description="Build TF-IDF baseline model.")
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--master", default=None)
    parser.add_argument("--config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    master_path = (
        ROOT / cfg["paths"]["sample_master"] if args.sample
        else (Path(args.master) if args.master else ROOT / cfg["paths"]["master_file"])
    )

    retriever, master_df, approved_codes = build_and_save(master_path, cfg)
    alias_map = build_alias_map_from_config(cfg)
    results_df = evaluate_sample(retriever, master_df, approved_codes, cfg)

    report_dir = ROOT / cfg["paths"]["reports_dir"]
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / "baseline_eval.html"
    results_df.to_html(report_path, index=False)
    print(f"\n✅  Evaluation report saved to: {report_path}")


if __name__ == "__main__":
    main()
