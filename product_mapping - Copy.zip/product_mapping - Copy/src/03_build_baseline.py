"""CLI entry-point for Phase 3. Logic lives in src/build_baseline.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.build_baseline import main
if __name__ == "__main__":
    main()
